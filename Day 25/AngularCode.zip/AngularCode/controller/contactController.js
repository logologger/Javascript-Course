
var app = angular.module('tutorialWebApp');
app.controller('contactCtrl', function( $rootScope,$scope ,customService) {

	//$scope.someData=$rootScope.someData;

	$scope.message="Welcome to Contact Us Page";
	$scope.someData="This is some Set of Data coming from controller";

	//chartJS data

	$scope.labels = ["January", "February", "March", "April", "May", "June", "July"];
  $scope.series = ['Series A', 'Series B'];
  $scope.data1 = [
    [65, 59, 80, 81, 56, 55, 40],
    [28, 48, 40, 19, 86, 27, 90]
  ];
  $scope.onClick = function (points, evt) {
    console.log(points, evt);
  };
  $scope.datasetOverride = [{ yAxisID: 'y-axis-1' }, { yAxisID: 'y-axis-2' }];
  $scope.options = {
    scales: {
      yAxes: [
        {
          id: 'y-axis-1',
          type: 'linear',
          display: true,
          position: 'left'
        },
        {
          id: 'y-axis-2',
          type: 'linear',
          display: true,
          position: 'right'
        }
      ]
    }
};


	//chartJS data
  

	$scope.cars=[
	{
		name:'Maruti 800',
		numOfSales:800,
		price:200

	},{
		name:'Maruti Switz',
		numOfSales:800,
		price:200

	},{
		name:'Maruti 100',
		numOfSales:800,
		price:200

	},
	{
		name:'Tata',
		numOfSales:900,
		price:100

	},{
		name:'Ashok Leyland',
		numOfSales:700,
		price:500000

	},
	{
		name:'BMW',
		numOfSales:100,
		price:70000

	},
	{
		name:'Mahindra',
		numOfSales:500,
		price:90000

	},
	{
		name:'Porsche',
		numOfSales:300,
		price:1000

	}
	]

	console.log("CustomService Prime Number Check ",customService.checkPrime(11));
   

   
});