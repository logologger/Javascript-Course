var app = angular.module('tutorialWebApp', [
    'ngRoute','720kb.datepicker','chart.js'
]);

app.config(['$routeProvider', '$locationProvider', function($routeProvider, $locationProvider) { //services
    $routeProvider
    // Home
        .when("/", //default

            {
                templateUrl: "partials/home.html",
                controller: "PageCtrl"
            })
        // Pages
        .when("/about",

            {
                templateUrl: "partials/about.html",

                controller: "aboutCtrl"
            })
        .when("/faq", { templateUrl: "partials/faq.html", controller: "PageCtrl" })
        .when("/pricing", { templateUrl: "partials/pricing.html", controller: "PageCtrl" })
        .when("/services", { templateUrl: "partials/services.html", controller: "PageCtrl" })
        .when("/contact", {

            templateUrl: "partials/contact.html",

            controller: "contactCtrl"
        })
        // Blog
        .when("/blog", { templateUrl: "partials/blog.html", controller: "BlogCtrl" })
        .when("/blog/post", { templateUrl: "partials/blog_item.html", controller: "BlogCtrl" })
        // else 404
        .otherwise("/404", { templateUrl: "partials/404.html", controller: "PageCtrl" });



    $locationProvider.html5Mode(false);
}]);

// app.controller('BlogCtrl', function( /* $scope, $location, $http */ ) {
//     console.log("Blog Controller reporting for duty.");
// });
