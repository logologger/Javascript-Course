var app=angular.module("tutorialWebApp");

app.filter("personalFilter",function(){
	return function(data){

		return data.substr(0,4) +" car";

	};
});