var app=angular.module('tutorialWebApp');


app.service('customService',function(){

	this.checkPrime=function(a){

		//logic for prime number check
		var isPrime=true;
		for(var i=2;i<a;i++){
			if(a%i==0){

				

				//means it has common factor
				//then its not a prime number
				isPrime=false;
				break;
			}
		}

		//performed some common operation

		return isPrime;


	}

	this.addTwoNumbers=function(a,b){

		return a+b;




	}

	this.loadGoogleMap=function(){

		//IT will load the GoogleMap and return the instance of it





	}





})