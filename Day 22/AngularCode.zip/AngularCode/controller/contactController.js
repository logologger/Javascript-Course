
var app = angular.module('tutorialWebApp');
app.controller('contactCtrl', function( $rootScope,$scope ,customService) {

	//$scope.someData=$rootScope.someData;

	console.log("CustomService Prime Number Check ",customService.checkPrime(11));
   

   
});