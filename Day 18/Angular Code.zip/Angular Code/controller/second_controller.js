var app = angular.module("first_module"); //You are not creating a instance ..you are actually defining it

app.controller("second_controller", function($scope) {

	


});