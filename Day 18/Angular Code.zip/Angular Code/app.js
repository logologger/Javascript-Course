
var app = angular.module("first_module",[]);//Defined our module

//Make a new instance of our application ... create a memory section where your appliation will get loaded

//[]  -- Tells there are some other modules on whih our angular Application depends
//on other module


