
var app = angular.module('tutorialWebApp');
app.controller('contactCtrl', function( $rootScope,$scope ) {

	$scope.someData=$rootScope.someData;
   

   
});