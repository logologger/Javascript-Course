
var app = angular.module('tutorialWebApp');
app.controller('aboutCtrl', function( $scope , $http, $rootScope) {//service



	console.log("About Controller got loaded");

	

	$scope.aboutText="Lid est laborum dolo rumes fugats untras. Etharums ser quidem rerum facilis dolores nemis omnis fugatsvitaes nemo minima rerums unsers sadips amets.. Sed ut perspiciatis unde omnis iste natus error sitvoluptatem accusantium doloremque laudantium, totam rem aperiam, eaque ipsa quae ab illo inventoreveritatis et quasi architecto beatae vitae dicta sunt explicabo. Nemo enim ipsam voluptatem quiavoluptas sit aspernatur aut odit aut fugit, sed quia consequuntur magni dolores eos qui rationevoluptatem sequi nesciunt";

	//ajax  may be coming from server
	//ajax calls we use $http
	$http.get('https://jsonplaceholder.typicode.com/posts')//When this task of getting the json data
		.then(function(response){  //json data in the response

			//console.log(response);

			$scope.aboutUs_data=response.data[0].body;
			$rootScope.someData=$scope.aboutUs_data;

		});



    
});