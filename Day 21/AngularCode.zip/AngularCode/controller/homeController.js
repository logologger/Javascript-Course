
var app = angular.module('tutorialWebApp');
app.controller('PageCtrl', function( /* $scope, $location, $http */ ) {
   

    // Activates the Carousel
    $('.carousel').carousel({
        interval: 5000
    });

    // Activates Tooltips for Social Links
    $('.tooltip-social').tooltip({
        selector: "a[data-toggle=tooltip]"
    })
});