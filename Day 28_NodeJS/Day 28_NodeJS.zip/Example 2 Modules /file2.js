var file=require('./file1');


console.log(file);

//  { server_log: [Function: print_me_the_server_logs] }

file.server_log;

console.log(file.variable);

file.image_download_link();

file.give_me_student_data();