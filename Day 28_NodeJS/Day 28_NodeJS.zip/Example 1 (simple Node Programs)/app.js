console.log("\n\n\n\n\n====================NodeJS=============== \n\n\n\n\n\n");
console.log("\n\n\n\n\n====================Extermely Fast=============== \n\n\n\n\n\n");


// Multi threading

// Asynchornous 

var a=12;
var b=a+24;
console.log(b);

console.log("%c Text","font-size:20px");
console.log("There was some error in this file "+__filename); //Global Variables

console.log(__dirname+"images.png");

