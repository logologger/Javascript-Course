var app=angular.module("myApp");

app.controller("TimerCtrl",function($scope,$state){



$scope.time_left="12:30:45";

//One Logic here 
//Timer 45 seconds 44 43 42 00 --> 30 --29 (60)-->




});