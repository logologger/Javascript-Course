var app = angular.module("myApp", ['ui.router','appRoutes']);

