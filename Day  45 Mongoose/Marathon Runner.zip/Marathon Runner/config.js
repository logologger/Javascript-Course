module.exports={

	"database":"mongodb://localhost:27017/marathon_runner",
	"port":process.env.PORT || 3000



};