
var app = angular.module('tutorialWebApp');
app.controller('aboutCtrl', function( $scope , $http, $rootScope,customService,commonFactory) {//service



	console.log("About Controller got loaded");

	console.log("Is 4 a prime Number "+customService.checkPrime(4));

	$scope.message="Welcome to About Us Page";
	


	$scope.checkPrime=function(){


		console.log("Check Prime Function got called");

		var number=angular.element("#primeNumber").val();
		if(number===""){
			$scope.result=false;
			return;
		}
		number=parseInt(number);//convert this to number from string

		

		var result=commonFactory.checkPrime(number);

		$scope.result=result;

	}

	

	$scope.aboutText="Lid est laborum dolo rumes fugats untras. Etharums ser quidem rerum facilis dolores nemis omnis fugatsvitaes nemo minima rerums unsers sadips amets.. Sed ut perspiciatis unde omnis iste natus error sitvoluptatem accusantium doloremque laudantium, totam rem aperiam, eaque ipsa quae ab illo inventoreveritatis et quasi architecto beatae vitae dicta sunt explicabo. Nemo enim ipsam voluptatem quiavoluptas sit aspernatur aut odit aut fugit, sed quia consequuntur magni dolores eos qui rationevoluptatem sequi nesciunt";

	//ajax  may be coming from server
	//ajax calls we use $http
	$http.get('https://jsonplaceholder.typicode.com/posts')//When this task of getting the json data
		.then(function(response){  //json data in the response

			//console.log(response);

			$scope.aboutUs_data=response.data[0].body;
			$rootScope.someData=$scope.aboutUs_data;

		});

		// $ajax --- 



    
});