var app=angular.module("tutorialWebApp");


app.directive('aboutMe',function(){


	var aboutMeDirective={};

	//aboutMeDirective.replace=true;

	aboutMeDirective.restrict='E';//This is an Element Directive

	aboutMeDirective.templateUrl='/Directives/aboutME/aboutMe.html';

	// aboutMeDirective.scope={
	// 	name : "=name"//only in one direction data binding
	// }


	aboutMeDirective.controller=function($scope){


		$scope.message="This is from My Directive";
	}


	aboutMeDirective.compile = function(element,attributes){

		element.css("color","red");
		


		var link=function($scope,element,attributes){

			$scope.message="Welcome to link function inside Directive "; //bind 
							//attach event
			//attach the event listeners here
			//templateURl
			// element.bind("click",function(){

			// 	alert("Directive Elements got clicked");
			// $scope.rajat={};

			// $scope.rajat.frstName="This is Rajat";

			// $scope.ajay={};
			// $scope.ajay.frstName="This is Ajay";


			// });

			//$scope.name.rajat={};
			

			

		}

		return link;



	}



	return aboutMeDirective;







});


/*
 <about-me></about-me>--->Element Directive --E

            <p about-me="rja"></p> ---->Attribute Directive --A

            <!-- about-me -->--Comment Directive --M

            <p class="about-me"></p>--Class Directive --C

*/