var app=angular.module("first_module");


app.controller("class_controller",function($scope){


	$scope.classNames="Name of the Classes will be taken 1 by 1";
})