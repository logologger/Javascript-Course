var app=angular.module("tutorialWebApp");

app.factory("commonFactory",function(){

	var factory={};


	factory.checkPrime=function(a){

		//logic for prime number check

		

		if(a==1){
			return false;
		}
		var isPrime=true;
		for(var i=2;i<a;i++){
			if(a%i==0){

				//means it has common factor
				//then its not a prime number
				isPrime=false;
				break;
			}
		}

		//performed some common operation

		return isPrime;




	}

	factory.operation2=function(){





	}

	factory.operation3=function(){



	}

	return factory;





})