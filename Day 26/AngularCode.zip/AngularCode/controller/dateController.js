

var app = angular.module('tutorialWebApp');
app.controller('DateCtrl', function( $rootScope,$scope ,customService) {

	//$scope.someData=$rootScope.someData;

	

	//NoData Needed forDate

});
