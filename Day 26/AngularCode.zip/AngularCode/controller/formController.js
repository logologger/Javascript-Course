
var app = angular.module('tutorialWebApp');
app.controller('formCtrl', function( $rootScope,$scope ,customService) {

	$scope.fname="Rajat";
	$scope.$watch('fname', function(newValue, oldValue, scope) {

		console.log(oldValue+"   "+newValue);
		
	});
	$scope.$watch(function(){
		console.log('Watch got fired');
	})



});


//angular.element(document.getElementById('firstname')).scope().$apply()
//angular.element(document.getElementById('firstname')).scope().fname="Singh"